import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Пользователь вводит размер доски (и количество ферзей)
        System.out.print("Введите количество ферзей (размер доски N x N): ");
        int n = scanner.nextInt();

        // Создаём доску N x N
        NQueens game = new NQueens(n);

        System.out.println("\n=== ЗАДАЧА О " + n + " ФЕРЗЯХ ===");
        System.out.println("Расстановка " + n + " ферзей на доске " + n + "x" + n + " так,");
        System.out.println("чтобы они не били друг друга\n");

        // Запускаем поиск решения
        if (game.solve()) {
            game.printBoard();
        } else {
            System.out.println("Решение не найдено для доски " + n + "x" + n);
        }

        scanner.close();
    }
}

/**
 * Класс для решения задачи о N ферзях
 * (обобщение классической задачи о 8 ферзях)
 */
class NQueens {
    int size;          // размер доски (size x size) и количество ферзей
    int[] queens;      // массив, где queens[row] = column

    /**
     * Конструктор
     * @param size - размер доски и количество ферзей
     */
    NQueens(int size) {
        this.size = size;
        this.queens = new int[size];

        // Инициализируем массив значением -1 (ферзь не поставлен)
        for (int i = 0; i < size; i++) {
            queens[i] = -1;
        }
    }

    /**
     * Основной метод решения
     * @return true, если решение найдено
     */
    boolean solve() {
        return placeQueen(0);
    }

    /**
     * Рекурсивный метод расстановки ферзей
     * @param row - текущая строка (0-based)
     * @return true, если удалось расставить всех ферзей
     */
    boolean placeQueen(int row) {
        // Базовый случай: если расставили всех ферзей (row == size)
        if (row == size) {
            return true;
        }

        // Пробуем поставить ферзя в текущей строке во все столбцы
        for (int col = 0; col < size; col++) {
            if (isSafe(row, col)) {
                queens[row] = col;           // ставим ферзя

                if (placeQueen(row + 1)) {   // рекурсивно ставим следующего
                    return true;
                }

                queens[row] = -1;            // откат (backtracking)
            }
        }

        return false;  // ни один столбец не подошёл
    }

    /**
     * Проверка безопасности позиции (row, col)
     * @param row - строка
     * @param col - столбец
     * @return true, если позиция безопасна
     */
    boolean isSafe(int row, int col) {
        // Проверяем всех уже поставленных ферзей (строки от 0 до row-1)
        for (int i = 0; i < row; i++) {
            int placedCol = queens[i];

            // Проверка по вертикали
            if (placedCol == col) {
                return false;
            }

            // Проверка по диагонали
            if (Math.abs(row - i) == Math.abs(col - placedCol)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Вывод шахматной доски в консоль
     */
    void printBoard() {
        System.out.println("=== РАССТАНОВКА " + size + " ФЕРЗЕЙ ===");

        // Верхняя граница
        System.out.print("  +");
        for (int i = 0; i < size; i++) {
            System.out.print("---");
        }
        System.out.println("-+");

        // Вывод строк
        for (int row = 0; row < size; row++) {
            System.out.print((row + 1) + " | ");

            for (int col = 0; col < size; col++) {
                if (queens[row] == col) {
                    System.out.print("Q ");
                } else {
                    System.out.print(". ");
                }
            }
            System.out.println("|");
        }

        // Нижняя граница
        System.out.print("  +");
        for (int i = 0; i < size; i++) {
            System.out.print("---");
        }
        System.out.println("-+");

        // Подписи столбцов
        System.out.print("    ");
        for (int col = 0; col < size; col++) {
            System.out.print((char)('a' + col) + " ");
        }
        System.out.println();

        // Координаты ферзей
        System.out.println("\nКоординаты ферзей:");
        for (int row = 0; row < size; row++) {
            char colLetter = (char)('a' + queens[row]);
            System.out.println("Ферзь " + (row + 1) + ": " + colLetter + (row + 1));
        }
    }
}